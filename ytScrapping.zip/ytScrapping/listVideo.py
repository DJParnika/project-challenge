from urllib.request import Request
from flask_cors import CORS, cross_origin
from selenium import webdriver
from bs4 import BeautifulSoup
import mysql.connector as connection
from flask import Flask, render_template, request,jsonify
import time
from selenium.webdriver import Chrome
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from pytube import extract
import requests




mydb = connection.connect(host="localhost", user="root", passwd="Kevali108$")

app = Flask(__name__)

@app.route('/',methods=['GET'])  # route to display the home page
@cross_origin()
def homePage():
    return render_template("index.html")

@app.route('/listVideos',methods=['POST','GET']) # route to show the review comments in a web UI
@cross_origin()
def getVideoList():
    if request.method == 'POST':
        try:
            search_url = request.form['content'].replace(" ","")
            print(search_url)

            driver = webdriver.Chrome()
            driver.get('{}/videos?view=0&sort=p&flow=grid'.format(search_url))#latest video page of channel
            content = driver.page_source.encode('utf-8').strip()
            soup = BeautifulSoup(content, 'lxml')
            video_id = extract.video_id(search_url)
            print(video_id)
            titles = soup.findAll('a',id='video-title')
            video_views = soup.findAll('span',class_='style-scope ytd-grid-video-renderer')

            video_urls = soup.findAll('a',id='video-title')

            cursor = mydb.cursor()
            i = 0
            j = 0
            k = 1
            for title in titles[:20]:
               # mydict = {"Search_url": search_url, "video_title": title.text, "video_link": "https://www.youtube.com" + video_urls[i].get('href') }
               #videoList.append(mydict)

                    q1 = "INSERT INTO youtube.yt_videoList (video_id, video_title, video_link, video_views, video_posted_on) VALUES (%s,%s,%s,%s,%s)"
                    cursor.execute(q1,(video_id, title.text, "https://www.youtube.com" + video_urls[i].get('href'), video_views[j].text, video_views[k].text))
                    mydb.commit()
                    i+=1
                    j+=2
                    k+=2

            q2= """SELECT * FROM youtube.yt_videoList where video_id = %s"""
            cursor = mydb.cursor()
            cursor.execute(q2,(video_id,))
            videos = cursor.fetchall()
            driver.close()
            return render_template('results.html', videos=videos[0:(len(videos)-1)])

        except Exception as e:
             print('The Exception message is: ', e)
             return 'something is wrong'

    else:
        return render_template('index.html')

@app.route('/get_url',methods=['GET'])  # route to display the home page
@cross_origin()
def getURL():
    return render_template("videoDetails.html")

@app.route('/VideoDetails',methods=['POST','GET']) # route to show the review comments in a web UI
@cross_origin()
def getVideoDetails():
    if request.method == 'POST':
        try:
            search_url = request.form['content'].replace(" ","")
            print(search_url)
            comments = []
            commenters = []
            with Chrome() as driver:
                wait = WebDriverWait(driver, 10)
                driver.get(search_url)
                #driver.get("https://www.youtube.com/watch?v=Pp6CO2_YEDE")

                for item in range(5):  # by increasing the highest range you can get more content
                    wait.until(EC.visibility_of_element_located((By.TAG_NAME, "body"))).send_keys(Keys.END)
                    time.sleep(3)

                for comment in wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, "#comment #content-text"))):
                    comments.append(comment.text)
                    print(comment.text)

                for commenter in wait.until(EC.presence_of_all_elements_located((By.CSS_SELECTOR, "#comment #author-text"))):
                    print(commenter.text)
                    commenters.append(commenter.text)

                return render_template('comments.html')
        except Exception as e:
             print('The Exception message is: ', e)
             return 'something is wrong'

    else:
        return render_template('results.html')





if __name__ == "__main__":
    app.run(host='127.0.0.1', port=5000, debug=True)

